VISUALTEST.ORG


Prerequisites:
   To run Visual Test Automaton Framework you need Java 1.7+ and Chrome Browser (32-bit!!! )



To run:
1. Start VisualTAF.exe
2. Right click on Test Set node and create new Test Set
3. Drag and drop "TestSuite1 - ticket creation test cases.xlsx" file into created test set
4. Drag and drop "TicketsAUT-Keywords.jar" to Dependencies node
5. Right click on test set and choose "Run selected test set" option
6. Select number of parallel threads for execution
7. Test Execution will start in Chrome Browser
