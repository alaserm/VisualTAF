
var driver;


var Util = {};
Util.startLocalWebDriver = function(params) {
	
    if(params.get("browser") == "Chrome")
        driver =new ChromeDriver;
    else
    if(params.get("browser") == "Firefox")    
        driver =new FirefoxDriver;
    else
        throw new UnsupportedOperationException();

    
    //driver.executeScript("alert('atas')" );	
        
        
    //return "PASS";

}
Util.closeWebDriver = function() {
            if( driver )
              driver.quit();
}
Util.isElementVisible = function(by) {
        try {
            if (driver.findElement(by).isDisplayed()) {
                return true;
            } else {
                return false;
            }

        } catch (ex) {
            return false;
        }
    
}




