
//encapsulates all actions related to login

var Login = {};
Login.login = function(params) {
	
        //print(params.get("browser") );

        driver.get("http://23.236.144.243/TodosAUT/public/login");
        
        //driver.findElement(By.cssSelector("input#email")).sendKeys(params.get("email"));
	
        LoginPage.username.sendKeys(params.get("email"));
        LoginPage.password.sendKeys(params.get("password"));
        LoginPage.goButton.click();

}
