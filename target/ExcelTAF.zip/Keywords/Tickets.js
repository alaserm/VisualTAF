
//encapsulates all actions related to Tickets

var Tickets = {};
Tickets.createNew = function(params) {
        
        driver.get("http://23.236.144.243/TodosAUT/public/tickets/create");     
        
        if( params.get("subject") != null )
            TicketsNewPage.subjectTextBox.sendKeys(params.get("subject"));
        if( params.get("description") != null)
            TicketsNewPage.descriptionTextBox.sendKeys(params.get("description"));
        
        TicketsNewPage.createButton.click();        
}

Tickets.verifyTicketPresence = function(params) {

        driver.get("http://23.236.144.243/TodosAUT/public/tickets");     

        //TicketsIndexPage.ticketsTable.findElementByXPath("//tr[td[2]='"+params.get("subject")+"' and td[3]='"+params.get("description")+"']" );
        
        if( Util.isElementVisible( By.xpath("//tr[td[2]='"+params.get("subject")+"' and td[3]='"+params.get("description")+"']") ) )
            return "FOUND";
        
        return "NOTFOUND";    
}

