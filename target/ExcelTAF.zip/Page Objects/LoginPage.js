
//Encapsulates page objects of Login page

var LoginPage = {

    get username() {
        return driver.findElement(By.cssSelector("input#email"));
    },

    get password() {
        return driver.findElement(By.cssSelector("input#password"));
    },    

    get goButton() {
        return driver.findElement(By.cssSelector("button.btn-primary"));
    }    
    
};
