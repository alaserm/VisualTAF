
var TicketsNewPage = {

    get subjectTextBox() {
        return driver.findElement(By.cssSelector("input#subject"));
    },

    get descriptionTextBox() {
        return driver.findElement(By.cssSelector("textarea#description"));
    },    

    get createButton() {
        return driver.findElement(By.cssSelector("input.btn-primary[type='submit']"));
    }    
    
};
