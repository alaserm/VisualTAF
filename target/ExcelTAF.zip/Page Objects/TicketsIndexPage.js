
//bindings to objects of Ticket Index Page

var TicketsIndexPage = {

    get addNewButton() {
        return driver.findElement(By.cssSelector("a[title='Add New ticket']"));
    },

    get searchBox() {
        return driver.findElement(By.cssSelector("input[name='search']"));
    },    

    get ticketsTable() {
        return driver.findElement(By.cssSelector("table.table-borderless") );
    }    
    
};
